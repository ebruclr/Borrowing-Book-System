using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

public class LibIdentityDbContext : IdentityDbContext
{
    public LibIdentityDbContext(DbContextOptions<LibIdentityDbContext> options) : base(options) {}
}
