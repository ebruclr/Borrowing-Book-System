using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

public class BorrowController : Controller
{
    private readonly AppDbContext _context;

    public BorrowController(AppDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        ViewData["Title"] = "Borrow";
        return View();
    }

    [Authorize(Roles = "User,Admin")]
    [HttpGet]
    public IActionResult Borrow()
    {
        var books = _context.Books.ToList();
        return View(books);
    }

    [Authorize(Roles = "User,Admin")]
    [HttpPost]
    public IActionResult Borrow(string Title)
    {
        // Get the current user's ID.
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        
        // Check whether the user already has a borrowed book.
        var userHasBorrowedBook = _context.Books.Any(b => b.BorrowedByUserId == userId && b.isBorrowed);
        
        if (userHasBorrowedBook)
        {
            TempData["Error"] = "You already have a borrowed book. You need to return it first!";
            return RedirectToAction("Borrow");
        }

       var borrowedBook = _context.Books.FirstOrDefault(b => b.Title == Title);

        if (borrowedBook != null && !borrowedBook.isBorrowed)
        {
            borrowedBook.isBorrowed = true;
            borrowedBook.BorrowedByUserId = userId;
            _context.SaveChanges();
            
            TempData["Success"] = "The book has been successfully borrowed.";
        }

        return RedirectToAction("List");
    }

    [HttpGet]
    public IActionResult List()
    {
        var books = _context.Books.ToList();
        return View(books);
    }

    [Authorize(Roles = "User,Admin")]
    [HttpGet]
    public IActionResult Return()
    {
        var books = _context.Books.ToList();
        return View(books);
    }

    [Authorize(Roles = "User,Admin")]
    [HttpPost]
    public IActionResult Return(string Title)
    {
        var borrowedBook = _context.Books.FirstOrDefault(b => b.Title == Title);

        if (borrowedBook != null && borrowedBook.isBorrowed)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var isAdmin = User.IsInRole("Admin");
            if (borrowedBook.BorrowedByUserId == userId || isAdmin)
            {
                borrowedBook.isBorrowed = false;
                borrowedBook.BorrowedByUserId = null;
                _context.SaveChanges();
            }
            else
            {
                return RedirectToAction("Return");
            }
        }

        return RedirectToAction("List");
    }
}
