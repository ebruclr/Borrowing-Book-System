using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

public class BookController : Controller
{
    private readonly AppDbContext _context;

    public BookController(AppDbContext context)
    {
        _context = context;
    }

    // LIST PAGE (BOOK LIST)
    [HttpGet]
    public IActionResult Index()
    {
        ViewData["Title"] = "Book List";
        return View();
    }

    // LIST METHOD
    [HttpGet]
    public IActionResult List()
    {
        var books = _context.Books.ToList();
        return View(books);
    }

    // CREATE GET
    [Authorize(Roles = "Admin")]
    public IActionResult Create()
    {
        int newbookid;
        try
        {
            newbookid = _context.Books.Max(b => b.BookID) + 1;
        }
        catch
        {
            newbookid = 1;
        }

        ViewBag.newbookid = newbookid;
        return View();
    }

    // CREATE POST
    [Authorize(Roles = "Admin")]
    [HttpPost]
    public IActionResult Create(Book book)
    {
        _context.Books.Add(book);
        _context.SaveChanges();
        return RedirectToAction("List");
    }

    // DELETE
    [Authorize(Roles = "Admin")]
    [HttpPost]
    public IActionResult Delete(int BookID)
    {
        var book = _context.Books.Find(BookID);
        if (book != null)
        {
            _context.Books.Remove(book);
            _context.SaveChanges();
        }

        return RedirectToAction("List");
    }

    // UPDATE GET
    [Authorize(Roles = "Admin")]
    [HttpPost]
    public IActionResult Update(int BookID)
    {
        var book = _context.Books.Find(BookID);
        return View(book);
    }

    // UPDATE POST
    [Authorize(Roles = "Admin")]
    [HttpPost]
    public IActionResult UpdateBook(Book updated)
    {
        var book = _context.Books.Find(updated.BookID);
        if (book != null)
        {
            book.Title = updated.Title;
            book.Author = updated.Author;
            _context.SaveChanges();
        }

        return RedirectToAction("List");
    }
}
