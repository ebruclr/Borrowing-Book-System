using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;

public class AccountController : Controller
{
    private readonly SignInManager<IdentityUser> _signInManager;
    private readonly UserManager<IdentityUser> _userManager;
    public AccountController(SignInManager<IdentityUser> signInManager, UserManager<IdentityUser> usermanager)
    {
        _signInManager = signInManager;
        _userManager = usermanager;
    }
    
    public IActionResult Login()
    { 
        ViewData["Title"] = "Login";
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model, string? ReturnUrl = null){
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
            return View(model);
        }
        
        if (ModelState.IsValid){
            var user = await _userManager.FindByNameAsync(model.UserName);

            if (user != null){
                var result = await _signInManager.PasswordSignInAsync(user, model.Password, false, false);

                if (result.Succeeded){
                    return Redirect(ReturnUrl ?? "/"); 
                }
                else{
                    ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                }
            }
            else{
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
            }
        }
        return View(model); 
    }

    public async Task<IActionResult> Logout(){
        await _signInManager.SignOutAsync();
        return RedirectToAction("Login", "Account");
    }

    [HttpGet]
    public IActionResult Register()
    {
         ViewData["Title"] = "Register";
        return View();
    }
    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }
        var user = new IdentityUser
        {
            UserName = model.UserName,
            Email = model.Email
        };
        
        var result = await _userManager.CreateAsync(user, model.Password);

        if (result.Succeeded)
        {
            _userManager.AddToRoleAsync(user, "User").Wait();
            return RedirectToAction("Login", "Account");
        }

        foreach (var error in result.Errors)
        {
            ModelState.AddModelError("", error.Description);
        }
        
        return View(model);
    }
}