using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<AppDbContext>(options=>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddDbContext<LibIdentityDbContext>(opts => opts.UseSqlite(
    builder.Configuration.GetConnectionString("IdentityDbConnection")));
builder.Services.AddIdentity<IdentityUser, IdentityRole>()
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<LibIdentityDbContext>();
builder.Services.Configure<IdentityOptions>(options=>
{
   options.User.RequireUniqueEmail = true;
   options.Password.RequiredLength = 5;
   options.Password.RequireNonAlphanumeric = false;
   options.Password.RequireUppercase = false;
});

var app = builder.Build();

app.UseAuthentication();
app.UseAuthorization();
app.MapDefaultControllerRoute();

SeedIdentityData.EnsurePopulated(app);

app.Run();
