using System.ComponentModel;

public class Book
{
    public int BookID { get; set; }
    public string Title { get; set; }
    public string Author { get; set; }
    
    [DefaultValue(false)]
    public bool isBorrowed { get; set; }
    public string? BorrowedByUserId { get; set; }
}